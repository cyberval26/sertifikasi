<?php

class Dashboard extends CI_Controller
{
    public function index()
    {

        $this->m_security->getSecurity();
        $isi['content'] = 'homeView';
        $isi['judul'] = 'Dashboard';
        $this->load->view('dashboardView', $isi);
    }
}